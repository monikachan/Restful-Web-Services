from django.apps import AppConfig


class WeatherapiConfig(AppConfig):
    name = 'weatherapi'
