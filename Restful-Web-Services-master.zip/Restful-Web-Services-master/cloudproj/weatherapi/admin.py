from django.contrib import admin
from weatherapi.models import WeatherAPI

admin.site.register(WeatherAPI)